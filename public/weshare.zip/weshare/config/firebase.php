<?php
return [
    'iss' => env('FIREBASE_ISS'),
];